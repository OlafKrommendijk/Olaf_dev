<?php
$con = mysqli_connect("localhost", "root", "") or die("No Connection");
mysqli_select_db($con, "cargo") or die("No Database name");
